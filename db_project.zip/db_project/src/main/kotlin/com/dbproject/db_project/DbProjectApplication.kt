package com.dbproject.db_project

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class DbProjectApplication

fun main(args: Array<String>) {
	runApplication<DbProjectApplication>(*args)
}
