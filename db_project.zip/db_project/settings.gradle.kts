rootProject.name = "db_project"
